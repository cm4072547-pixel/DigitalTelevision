# DigitalTelevision Player — Android TV

A lightweight Android TV player for user-supplied M3U/M3U8 playlists. It remembers the last playlist URL locally and plays supported streams with AndroidX Media3 ExoPlayer.

## Build an APK

The repository includes a GitHub Actions workflow at `.github/workflows/build-apk.yml`.

1. Push the project to the `main` branch on GitHub, or open **Actions → Build Android TV APK → Run workflow**.
2. Wait for the workflow to finish successfully.
3. Open the completed workflow run and download the artifact named `DigitalTelevision-Player-AndroidTV-debug`.
4. Extract `app-debug.apk` and install it on the Android TV / TV box. Enable installation from unknown sources for the app used to open the APK if Android asks.

The workflow uses JDK 17, Gradle 8.9 and Android Gradle Plugin 8.7.3.

## Current functionality

- Android TV launcher entry and landscape interface.
- Remote HTTP/HTTPS M3U playlist URL input.
- Parses `#EXTINF` channel names and relative stream URLs.
- Saves the last playlist URL on the device.
- Plays streams supported by AndroidX Media3 ExoPlayer.
- D-pad-friendly channel list selection.

## Not yet implemented

This is an initial sideloadable player build, not a finished commercial IPTV platform. Xtream Codes login, EPG, catch-up, activation/account backend, parental controls, advanced favorites/search, and provider-specific stream compatibility are not implemented. The APK must still be tested on a physical Android TV device.

## Legal and privacy notes

The app does not ship with channels, playlists, provider credentials, or copyrighted media. Users must supply playlists and streams they are authorized to access. The last playlist URL is stored locally on the TV. HTTP cleartext is enabled for compatibility with providers that supply HTTP URLs; HTTPS is preferred.
